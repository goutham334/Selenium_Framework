package SupportHelperUtils;

import java.awt.AWTException;
import java.awt.Graphics2D;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
//import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
//import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.framework.Utility.Status;
import com.framework.Utility.selenium.CraftDriver;
import com.framework.Utility.selenium.ResultSummaryManager;

public class KeywordHelper extends ReusableLibrary {
	
	public static String javaErr = "JavaScript error";
	public static String MFExecution;
	public static String MFScreenshot;
	public static String rPath;
	
	public KeywordHelper(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

	/*
	 **************************************************************************************
	 * Method Name		: isObjectDisplayed
	 * Description		: this method will verify whether an UI element is displayed or not
	 * Input parameter	: web element, driver
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public boolean isObjectDisplayed(WebElement objDisplayed, String webElementName, String reportingYesNo){
		int attempts = 0;
		boolean isObDisp = false;
		while(attempts < 5){
			try{
				objDisplayed.isDisplayed();
				isObDisp = true;
				if (reportingYesNo.toUpperCase().equals("YES")){
					System.out.println(webElementName + " is displayed as expected in application screen");
					report.updateTestLog("Verify - '" + webElementName + "' is displayed", webElementName 
							+ " is displayed as expected in application screen", Status.PASS);			
				}
				break;
			}
			catch(StaleElementReferenceException ex) { 
				isObDisp= false;
				System.out.println(this.getClass().getName() + " Stale exception occured ***************");}
			catch(NoSuchElementException nEx){
				isObDisp= false;
				if (reportingYesNo.toUpperCase().equals("YES") || reportingYesNo.toUpperCase().equals("NO")){
					System.out.println(webElementName + " is not displayed in application screen");
					report.updateTestLog("Verify - '" + webElementName + "' is displayed", webElementName 
							+ " is not displayed as expected in application screen", Status.FAIL);					
				}
				break;
			}
			attempts++;
		}
		return isObDisp;
	}

	/*
	 ***************************************************************************************
	 * Method Name		: waitUntilClickable
	 * Description		: this method will waits until an UI element is clickable
	 * Input parameter	: locator
	 * Output parameter : flag
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public boolean waitUntilClickable(WebElement locator) {
		boolean bFlag = false;
		try {
			//System.out.println("waiting for element " + locator);
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			if((locator).isDisplayed()) {
				bFlag = true;
				System.out.println("Element " + locator + " is disaplyed and is clickable");
			}

		} catch (NoSuchElementException e) {
			System.out.println("Element " + locator + " was not displayed");
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + e.getMessage()
					, Status.FAIL);
		}

		catch (TimeoutException e) {
			System.out.println("Element " + locator + " was not clickable in time");
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + e.getMessage()
					, Status.FAIL);
		}

		catch (Exception e) {
			System.out.println("Element " + locator + " was not clickable");
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + e.getMessage()
					, Status.FAIL);
		}
		return bFlag;
	}

	/*
	 **************************************************************************************
	 * Method Name		: setHighlight
	 * Description		: this method will highlights the UI elements
	 * Input parameter	: web element, driver
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void setHighlight(WebDriver driver, WebElement element){
		int attempts = 0;
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String attributevalue = "border:3px solid green;";
		String getattib = element.getAttribute("style");
		while(attempts < 5){
			try{
				executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, attributevalue);
				try {
					Thread.sleep(200);
					executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, getattib);
					break;
				}catch(StaleElementReferenceException ex) { System.out.println(this.getClass().getName() + " Stale exception occured ***************");} 
				catch (Exception ex) {
					executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, getattib);
					ex.printStackTrace();
					Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
					report.updateTestLog(this.getClass().getName(),
							"Exception occured with message '" + ex.getMessage(), Status.FAIL);
				}
			}
			catch(Exception ex){
				Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
				report.updateTestLog(this.getClass().getName(),
						"Exception occured with message '" + ex.getMessage(), Status.FAIL);
				executor.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, getattib);
			}
			attempts++;
		}

	}

	/*
	 **************************************************************************************
	 * Method Name		: WaitObjEnabled
	 * Description		: this method will highlights the UI elements
	 * Input parameter	: web element, driver
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void WaitObjEnabled(WebElement objEnabled, String webElementName, String reportingYesNo){
		for(int i=0;i<5;i++){
			try{
				Boolean b = objEnabled.isEnabled();
				if (reportingYesNo.toUpperCase().equals("YES") && b == true){
					//report.updateTestLog("Check if object Enabled", webElementName + " - is enabled in application screen as expected", Status.DONE);
					//System.out.println(webElementName + " is Enabled as expected in application screen");
					break;
				}
			}
			catch(Exception ex){
				if (reportingYesNo.toUpperCase().equals("YES")){
					//report.updateTestLog("Check if object Enabled", webElementName + " - is not enabled in application screen now..", Status.DONE);
					//System.out.println(webElementName + " is not Enabled in application screen");
				}
				else{
					//report.updateTestLog("Check if object Enabled", webElementName + " is not Enabled in applicaiton screen reporting is set to NONE!!!", Status.DONE);
					//System.out.println(webElementName + " is not Enabled in application screen reporting is set to NONE!!!");
				}
			}
		}
	}
	/*
     **************************************************************************************
     * Method Name             : safeType
     * Description             : this method will enter the given text in a web element
     * Input parameter   : web element
     * Author                  : BOAO Automation
     ***************************************************************************************
     */

     public void safeTypeNoClear(WebElement objToEnterValue, String Value, String webElementName){
            try
            {
                   setHighlight(driver, objToEnterValue);
                   objToEnterValue.click();
                   objToEnterValue.sendKeys(Value);
                   if (!webElementName.toUpperCase().contains("PASSWORD")){
                         report.updateTestLog("Enter Value in - " + webElementName,
                                       "'" + Value + "' value is entered in " + webElementName, Status.DONE);}
                   else
                   {
                         report.updateTestLog("Enter Value in - " + webElementName,
                                       "'" + "******" + "' value is entered in " + webElementName, Status.DONE);
                   }
            }
            catch(NoSuchElementException ex){
                   Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
                   report.updateTestLog(this.getClass().getName(),
                                "Exception occured with message '" + ex.getMessage(), Status.FAIL);
            }
     }


	/*
	 **************************************************************************************
	 * Method Name		: isObjectTempDisplayed
	 * Description		: this method will verify whether an UI element is displayed or not
	 * Input parameter	: web element, driver
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public boolean isObjectTempDisplayed(WebElement objDisplayed, String webElementName, String reportingYesNo){
		boolean objDisplFlag = false;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		try{
			objDisplayed.isDisplayed();
			if (reportingYesNo.toUpperCase().equals("YES")){
				//System.out.println(webElementName + " is displayed as expected in application screen");
				report.updateTestLog("Verify - '" + webElementName + "' is displayed", webElementName + " is displayed as expected in applicaiton screen", Status.PASS);
				objDisplFlag = true;
			}
		}
		catch(NoSuchElementException nEx){
			objDisplFlag = false;
		}
		catch(Exception ex){
			objDisplFlag = false;
		}
		driver.manage().timeouts().implicitlyWait(45, TimeUnit.SECONDS);
		return objDisplFlag;
	}

	/*
	 **************************************************************************************
	 * Method Name		: isObjectNotDisplayed
	 * Description		: this method will verify whether an UI element is not displayed
	 * Input parameter	: web element, driver
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void isObjectNotDisplayed(WebElement objDisplayed, String webElementName, String reportingYesNo){
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		int attempts = 0, x = 1,y = 1;
		while(attempts < 5){
			try{
				x = objDisplayed.getLocation().getX();
				y = objDisplayed.getLocation().getY();
				System.out.println("position is " + x  + ","+ y);
				System.out.println(webElementName + " is displayed as unexpected in application screen");
				break;
				//report.updateTestLog("Verify - '" + webElementName + "' is displayed", webElementName 
				//	+ " is displayed in applicaiton where actually it shouldn't be displayed in application screen", Status.FAIL);
			}
			catch(StaleElementReferenceException ex) { System.out.println(this.getClass().getName() + " Stale exception occured ***************");}
			catch(NoSuchElementException nEx){
				if (reportingYesNo.toUpperCase().equals("YES") || reportingYesNo.toUpperCase().equals("NO")){
					x=0; y=0;
					System.out.println(webElementName + " is not displayed in application screen");
					//report.updateTestLog("Verify - '" + webElementName + "' is not displayed", webElementName 
					//	+ " is not displayed in application as expected", Status.PASS);
				}
			}
			attempts++;
		}
		if (x == 0 || y ==0){
			report.updateTestLog("Verify - '" + webElementName + "' is not displayed", webElementName 
					+ " is not displayed in application as expected", Status.PASS);
		}

	}

	/*
	 **************************************************************************************
	 * Method Name		: safeType
	 * Description		: this method will enter the given text in a web element
	 * Input parameter	: web element
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void safeType(WebElement objToEnterValue, String Value, String webElementName){
		try
		{
			setHighlight(driver, objToEnterValue);
			objToEnterValue.clear();
			objToEnterValue.sendKeys(Value);
			if (!webElementName.toUpperCase().contains("PASSWORD")){
				report.updateTestLog("Enter Value in - " + webElementName,
						"'" + Value + "' value is entered in " + webElementName, Status.DONE);}
			else
			{
				report.updateTestLog("Enter Value in - " + webElementName,
						"'" + "******" + "' value is entered in " + webElementName, Status.DONE);
			}
		}
		catch(NoSuchElementException ex){
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + ex.getMessage(), Status.FAIL);
		}
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeClearType
	 * Description		: this method will clear an UI element and enter the given text 
	 * Input parameter	: web element
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void safeClearType(WebElement objToEnterValue, String Value, String webElementName){
		try
		{
			setHighlight(driver, objToEnterValue);
			objToEnterValue.click();
			objToEnterValue.clear();
			objToEnterValue.sendKeys(Value);
			report.updateTestLog("Enter Value in - " + webElementName,
					"'" + Value + "' value is entered in " + webElementName, Status.DONE);
		}
		catch(NoSuchElementException ex){
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog("EnterValue",
					"Exception occured with message '" + ex.getMessage()
					, Status.FAIL);
		}
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeClick
	 * Description		: this method will clear an UI element and enter the given text 
	 * Input parameter	: web element
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void safeClick(WebElement objClick, String webElementName){
		try{
			//driver.JS_ClickExector(objClick);			
			isObjectDisplayed(objClick, webElementName, "No");
			WaitObjEnabled(objClick, webElementName, "No");
			setHighlight(driver, objClick);
			objClick.click();
			report.updateTestLog("Click - " + webElementName, "Performed click operation on " + webElementName, Status.DONE);
		}
		catch(NoSuchElementException ex){
			report.updateTestLog("Verify - '" + webElementName + "' is displayed", webElementName 
					+ " is not displayed as expected in applicaiton screen", Status.FAIL);
		}
		catch (Exception e) {
			report.updateTestLog("performClick",
					"Exception occured with message in the element name '"+ webElementName + e.getMessage()
					, Status.FAIL);
		}
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeWaitForStaleElement
	 * Description		: this method will remove an existing proxy user from list of proxy users
	 * Input parameter	: Select value
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */
	public void safeWaitForStaleElement(WebElement element, int timeout) {
		try {
			WebDriverWait wait=new WebDriverWait(driver, timeout);
			//wait.ignoring(StaleElementReferenceException.class);
			wait.ignoring(Exception.class);
			wait.until(ExpectedConditions.stalenessOf(element));	
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(this.getClass().getName() + " Stale exception occured ***************");
			System.out.println(this.getClass().getName() + "Exception occured with message '" + e.getMessage());
			//report.updateTestLog(this.getClass().getName(),
					//"Exception occured with message '" + e.getMessage(), Status.FAIL);
		}
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeSelectFromCheckbox
	 * Description		: this method will select a text value from a check box 
	 * Input parameter	: web element, Select value
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void safeSelectFromCheckbox(WebDriver driver,String selectValue){
		try{
			List<WebElement> allOptions = driver.findElements(By.tagName("input"));
			for (WebElement option : allOptions) {
				if (selectValue.equals(option.getText())) {
					option.click();
					report.updateTestLog("Select value from checkbox", selectValue + " - value is selected from checkbox", Status.DONE);
					break;
				}
			}
		}
		catch (Exception e) {
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + e.getMessage()
					, Status.FAIL);
		}
	}
	

	/*
	 **************************************************************************************
	 * Method Name		: safeSelectFromListbox
	 * Description		: this method will select a text value from a list box 
	 * Input parameter	: web element, Select value
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void safeSelectFromListbox(WebElement iSelect, String selectValue){
		try{
			Select select = new Select(iSelect);
			List<WebElement> allOptions  = select.getOptions();
			for(int i=0; i < allOptions.size(); i++){
				//System.out.println(allOptions.get(i).getText());
				if (allOptions.get(i).getText().contains(selectValue)){
					select.selectByIndex(i);
					//System.out.println("Select value - '" + allOptions.get(i).getText() + "' from dropdownlist");
					report.updateTestLog("Select value from listbox", selectValue + " - value is selected from listbox", Status.DONE);
					break;
				}
			}
		}
		catch (Exception e) {
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + e.getMessage()
					, Status.FAIL);
		}
	}
	/*
	 **************************************************************************************
	 * Method Name		: safeSelectFromListbox
	 * Description		: this method will select a text value from a list box by Index
	 * Input parameter	: web element, Select Index
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void SelectFromListboxbyindex(WebElement iSelect, int selectindex){
		try{
			Select select = new Select(iSelect);
			select.selectByIndex(selectindex);
			String Value =iSelect.getText();
				if (iSelect.isSelected())
						{
					System.out.println( "Selected value from dropdown by index: " + Value);
					report.updateTestLog("Select value from listbox", Value + " - value is selected from listbox", Status.DONE);
					
				}
					
			
		}
		catch (Exception e) {
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + e.getMessage()
					, Status.FAIL);
		}
	}
	

	/*
	 **************************************************************************************
	 * Method Name		: VerifyValueFromListbox
	 * Description		: this method will Verify if text value displayed in list box 
	 * Input parameter	: web element, Select value, lstboxName
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void VerifyValueFromListbox(WebElement iSelect, String selectValue, String lstboxName){
		try{
			boolean lstVal = false;
			Select select = new Select(iSelect);
			List<WebElement> allOptions  = select.getOptions();
			for(int i=0; i < allOptions.size(); i++){
				System.out.println("Printing options - " + allOptions.get(i).getText());
				if (allOptions.get(i).getText().contains(selectValue)){
					lstVal = true;
					select.selectByIndex(i);
					//System.out.println("Select value - '" + allOptions.get(i).getText() + "' from dropdownlist");
					if (selectValue.equals("")){selectValue = "EMPTY";}
					report.updateTestLog("Verify value from listbox", selectValue + " - value is listed in " + lstboxName, Status.PASS);
					break;
				}
			}
			if (!lstVal){
				report.updateTestLog("Verify value from listbox", selectValue + " - value is not listed in " + lstboxName, Status.FAIL);
			}
		}
		catch (Exception e) {
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + e.getMessage(), Status.FAIL);
		}
	}
	
	
	
	/*
	 **************************************************************************************
	 * Method Name		: checkAlert
	 * Description		: this method will check window alert and accept it 
	 * Input parameter	: -
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */
	public void checkAlert() {
	    try {
	        WebDriverWait wait = new WebDriverWait(driver, 5);
	        wait.until(ExpectedConditions.alertIsPresent());
	        Alert alert = driver.switchTo().alert();
	        alert.accept();
	    } catch (Exception e) {
	        System.out.println("No Alert present");
	    }
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeClickLink
	 * Description		: this method will click a link of an UI element 
	 * Input parameter	: elementLink
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void safeClickLink(String elementLink){
		try{
			WebElement objClick = driver.findElement(By.linkText(elementLink));
			isObjectDisplayed(objClick, elementLink, "Yes");
			WaitObjEnabled(objClick, elementLink, "Yes");
			setHighlight(driver, objClick);
			objClick.click();
			report.updateTestLog("Click - " + elementLink, "Performed click operation on " + elementLink, Status.DONE);
		}
		catch(NoSuchElementException ex){
			report.updateTestLog("Verify - '" + elementLink + "' is displayed", elementLink 
					+ " is not displayed as expected in applicaiton screen", Status.FAIL);
		}
		catch (Exception e) {
			report.updateTestLog("performClick",
					"Exception occured with message in the element name '"+ elementLink + e.getMessage()
					, Status.FAIL);
		}
	}

	/*
	 **************************************************************************************
	 * Method Name		: checkBrowserState
	 * Description		: this method will select a text value from a list box 
	 * Input parameter	: web element, Select value
	 * Output parameter : readystate
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public String checkBrowserState(){
		String readyState = null;
		try{
			readyState = String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"));
			return readyState;
		}
		catch (Exception e) {
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + e.getMessage()
					, Status.FAIL);
		}
		return readyState;
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeClearValues
	 * Description		: this method will clear value from a text box 
	 * Input parameter	: web element
	 * Output parameter : 
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public void safeClearValues(WebElement ObjectToClear,String Value, String webElementName){
		try{
			ObjectToClear.clear();
		}
		catch(Exception ex){
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + ex.getMessage()
					, Status.FAIL);
		}
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeGetText
	 * Description		: this method will extract text from an UI element 
	 * Input parameter	: web element
	 * Output parameter : String text
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public String safeGetText(WebElement objToGetText){
		String expText = null;
		try{
			objToGetText.isDisplayed();
			//objToGetText.isEnabled();
			expText = objToGetText.getText();
			setHighlight(driver, objToGetText);
		}
		catch(NoSuchElementException noEx){
			report.updateTestLog("NoSuchElement exception", noEx.getMessage(), Status.FAIL);
		}
		catch (Exception ex) {
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog("getTextFromWebElement",
					"Exception occured with message '" + ex.getMessage()
					, Status.FAIL);
		}
		return expText;
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeValidateInputDetails
	 * Description		: this method will compare input value with runtime value
	 * Author			: TTS Automation
	 ***************************************************************************************
	 */

	public void safeValidateInputDetails(WebElement objToGetText,String inputValue,String fieldName){
		String expText = null;
		try{
			objToGetText.isDisplayed();
			objToGetText.isEnabled();
			expText = objToGetText.getText();
			setHighlight(driver, objToGetText);
			if (!inputValue.isEmpty()){
				if (expText.contains(inputValue)){
					report.updateTestLog("Verify update field value of "+fieldName,  inputValue, Status.PASS);
				}
				else{
					report.updateTestLog("Verify update field value of "+fieldName, "Expected value - "+ inputValue +" Actual value - "+expText, Status.FAIL);
				}
			}

		}

		catch(NoSuchElementException noEx){
			report.updateTestLog("NoSuchElement exception", noEx.getMessage(), Status.FAIL);
		}
		catch (Exception ex) {
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog("getTextFromWebElement",
					"Exception occured with message '" + ex.getMessage()
					, Status.FAIL);
		}

	}

	/*
	 **************************************************************************************
	 * Method Name		: safeGetTextHighlight
	 * Description		: this method will extract text from an UI element 
	 * Input parameter	: web element
	 * Output parameter : String text
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public String safeGetTextHighlight(WebElement objToGetText){
		String expText = null;
		try{
			objToGetText.isDisplayed();
			objToGetText.isEnabled();
			expText = objToGetText.getText();
			setHighlight(driver, objToGetText);
		}
		catch(NoSuchElementException noEx){
			report.updateTestLog("NoSuchElement exception", noEx.getMessage(), Status.FAIL);
		}
		catch (Exception ex) {
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog("getTextFromWebElement",
					"Exception occured with message '" + ex.getMessage()
					, Status.FAIL);
		}
		return expText;
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeGetAttribute
	 * Description		: this method will return the attribute of an UI element 
	 * Input parameter	: web element, attribute type
	 * Output parameter : String text
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public String GetAttributeValue(WebElement webElementObj, String attribute){
		String expAttributeVal = null;
		try{
			expAttributeVal = webElementObj.getAttribute(attribute);
		}
		catch(NoSuchElementException noEx){
			report.updateTestLog("GetAttribute from HTML Tag", "NoSuchElement exception with message - " + noEx.getMessage(), Status.FAIL);
		}
		catch(Exception ex){
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog("GetAttribute",
					"Exception occured with message '" + ex.getMessage()
					, Status.FAIL);
		}
		return expAttributeVal;
	}

	/*
	 **************************************************************************************
	 * Method Name		: safeSwitchToAlertPresent
	 * Description		: this method switch to an alert present in the UI 
	 * Input parameter	: web element
	 * Output parameter : boolean
	 * Author			: BOAO Automation
	 ***************************************************************************************
	 */

	public boolean safeSwitchToAlertPresent(WebDriver Driver) {
		boolean isAlert = false;
		try {
			Driver.switchTo().alert();
			report.updateTestLog("Verify is AlertPresent", "Alert is present and driver switched to alert window", Status.DONE);
			isAlert =  true;
		} catch (NoAlertPresentException e) {
			report.updateTestLog("Verify is AlertPresent", "There is no Alert present in current application screen.", Status.DONE);
			isAlert = false;
		}
		catch(Exception ex){
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + ex.getMessage()
					, Status.FAIL);
		}
		return isAlert;
	}

	/*
	 **************************************************************************************
	 * Method Name             : robotPressKey
	 * Description             : this method trigger key press and release of any key n number of times
	 * Input parameter   	   : count, keyboard key
	 * Author				   : BOAO Automation	
	 ***************************************************************************************
	 */
	public void robotPressKey(int key, int count) {
		try {
			for(int i=1; i<=count; i++) {
				Robot robot = new Robot();
				robot.keyPress(key);
				robot.keyRelease(key);
				Thread.sleep(500);
			}
		} catch (AWTException aex){
			aex.printStackTrace();
			report.updateTestLog(this.getClass().getName(), "Exception occured in robot keypress or keyrelease '" + aex.getMessage(), Status.FAIL);
		} catch (Exception e) {
			e.printStackTrace();
			report.updateTestLog(this.getClass().getName(), "Exception occured with message '" + e.getMessage(), Status.FAIL);
			
			
		}
	}

	/*
	 **************************************************************************************
	 * Method Name             : decodepass
	 * Description             : this method decode the password
	 * Input parameter   	   : Encoded password 
	 ***************************************************************************************
	 */	
	public static String decodepass(String strToDecrypt){
		Base64.Decoder decoder = Base64.getUrlDecoder();  
		String dStr = new String(decoder.decode(strToDecrypt));  
		return dStr;
	}

	/*
	 **************************************************************************************
	 * Method Name             : Encodepass
	 * Description             : this method Encode the password
	 * Input parameter   	   : Encoded password 
	 ***************************************************************************************
	 */

	public static String EncodePass(String strToEncrypt){
		// Getting encoder  
		Base64.Encoder encoder = Base64.getUrlEncoder();  
		// Encoding URL  
		String eStr = encoder.encodeToString(strToEncrypt.getBytes());  
		System.out.println("Encoded Pass: "+eStr); 
		return eStr;
	}

	/*
	 **************************************************************************************
	 * Method Name             : switchFrame
	 * Description             : this method switch to iframe based on the user input
	 * Input parameter   	   : string
	 * Author				   : BOAO Automation
	 ***************************************************************************************
	 */	
	public void switchFrame(String frameID){
		try {
			driver.switchTo().defaultContent();
			driver.switchTo().frame(frameID);
		}
		catch(NoSuchFrameException nf) {
			System.out.println("Frame not found: "+frameID);
			report.updateTestLog(this.getClass().getName(), "Exception occured in iframe switching '"+frameID + nf.getMessage(), Status.FAIL);
		}
		catch(Exception ex){
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog(this.getClass().getName(),
					"Exception occured with message '" + ex.getMessage()
					+ "'  in the page", Status.FAIL);
		}

	}

	public void setHighlight(CraftDriver driver, WebElement btn_CreateUser) {


	}

	/*
	 **************************************************************************************
	 * Method Name             : waitForSeconds
	 * Description             : this method will make the script wait for the time input by the user 
	 * Input parameter   	   : Time(Seconds) to wait 
	 * Author                  : CLIP Automation
	 ***************************************************************************************
	 */	
	public void waitForSeconds(int inTime){
		try{
			Thread.sleep(inTime*1000);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public String generateRandomNumber(int length){
		return RandomStringUtils.randomNumeric(length);
	}

	public void assertTextPresentInPage(WebElement objToGetText,String Data) throws RuntimeException {

		try {
			String strObj = Data;
			if (objToGetText.getText()
					.contains(strObj)) {
				System.out.println("assertTextPresent passed");
				report.updateTestLog("Verify text present in page", "Expected text '" + strObj
						+ "' is  present in the page", Status.PASS);

			} else {
				System.out.println("assertTextPresentInPage failed");
				throw new Exception("Expected text  '" + strObj
						+ "' is not present in the page");
			}
		} 
		catch (Exception ex) {
			Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
			report.updateTestLog("assertTextPresentInPage",
					"Exception occured with message '" + ex.getMessage()
					+ "'  in the page", Status.FAIL);
			//throw new ForcedException("assertTextPresentInPage", e.getMessage());
		}
	}

	/*
     **************************************************************************************
     * Method Name             : RobotPerformMove
     * Description             : this method will move the mouse pointer to given x y coordinates in ui
     * Input parameter             : x and y co-ordinates
     * Author                  : UWeb Automation
     ***************************************************************************************
     */
     public void RobotPerformMove(int offsetX, int offsetY) throws AWTException{
                     try{
                                     Robot robot = new Robot();
                                     robot.mouseMove(offsetX, offsetY);
                     }
                     catch(Exception ex){
                                     Logger.getLogger(this.getClass().getName()).log(Level.OFF, null, ex);
                                     report.updateTestLog(this.getClass().getName(),            "Exception occured with message '" + ex.getMessage()+ "'  in the page", Status.FAIL);
                     }
     }


	/*	public static List<WebElement> ListWebelementReturn(String value) {
		List<WebElement> Listvalue = driver.findElements(By.xpath(value));
		return Listvalue;
	}*/

	/* ######################### APPLICATION SPECIFIC METHODS ############################ */

	/*
	 **************************************************************************************
	 * Method Name             : InvokeVBS
	 * Description             : this method will invoke the vbs file to run the macros from Excel
	 * Input parameter   	   : None
	 * Author                  : TTS Automation
	 ***************************************************************************************
	 */	
	public void InvokeVBS(String Keyname){
		
		try {
			//Run the VBS macro using Runtime.getRuntime method
			Process p = Runtime.getRuntime().exec("wscript TestData\\Mainframe.vbs" + " " + Keyname);
			//wait for until macro to finish run 
			p.waitFor();
			//This method will update the mainframe results in html/excel reports and move the mainframescrenshots to current results path
			this.mainframewrapup();
		}
		//capture the exception error and print the same in trace
		catch(Exception ex){
			if(!ex.getMessage().contains(javaErr)){
				report.updateTestLog("Exception occured in method - " + this.getClass().getName(),
						"Exception message '" + ex.getMessage(), Status.FAIL);
				ex.printStackTrace();
			}
		}
	}
	
	/*
	 **************************************************************************************
	 * Method Name             : mainframewrapup
	 * Description             : This method will update the mainframe results in html/excel reports and move the mainframescrenshots to current results path
	 * Input parameter   	   : None
	 * Author                  : TTS Automation
	 ***************************************************************************************
	 */
public void mainframewrapup() throws IOException {
		
		try {
			if (ResultSummaryManager.reportPath != null) {
				rPath = ResultSummaryManager.reportPath;
			} else {
				rPath = System.getProperty("ReportPath");
			}
			//Move the mainframe screenshots to current execution results folder using copyDirectory method
			File source = new File("TestData\\Mainframe");
			File dest = new File(rPath + "\\Screenshots");
		    FileUtils.copyDirectory(source, dest);
		    this.waitForSeconds(2);
		    if (source.exists()){
		    	FileUtils.deleteDirectory(source);
		    }
		    //This method to reduce the mainframe screenshots size from MBs to KBs
		    this.waitForSeconds(2);
		    String fpath = rPath + "\\Screenshots";
		    this.ReduceScreenshotSize(fpath);
		    
			//Access the report.xls file to update the mainframe results in html/excel reports
			File file = new File(dest + "\\Report.xls");
			FileInputStream fis = new FileInputStream(file);
	        HSSFWorkbook wb = new HSSFWorkbook(fis);
	        HSSFSheet sheet = wb.getSheet("Report");
	        MFExecution = dataTable.getData("Mainframe", "MFExeccution");
	        //Update the results of mainframe using updateTestLog method
			int nTestInstances = sheet.getLastRowNum();
			for (int currentTestInstance = 1; currentTestInstance <= nTestInstances; currentTestInstance++) {
				String Step_Name = sheet.getRow(currentTestInstance).getCell(1).getStringCellValue().toString();
				String Description = sheet.getRow(currentTestInstance).getCell(2).getStringCellValue().toString();
				String strStatus = sheet.getRow(currentTestInstance).getCell(3).getStringCellValue().toString();
				MFScreenshot = sheet.getRow(currentTestInstance).getCell(5).getStringCellValue().toString();
				if(strStatus.equals("Done")){
					report.updateTestLog(Step_Name,Description,Status.DONE);
				}if(strStatus.equals("Pass")){
					report.updateTestLog(Step_Name,Description,Status.PASS);
				}if(strStatus.equals("Fail")){
					report.updateTestLog(Step_Name,Description,Status.FAIL);
				}
			}
			wb.close();
			MFExecution = null;
			//Delete the report.xls file
			this.waitForSeconds(2);
			if (file.exists()) {
	            file.delete();
	        }
		}
		//capture the exception error and print the same in trace
		catch(Exception ex){
			if(!ex.getMessage().contains(javaErr)){
				report.updateTestLog("Exception occured in method - " + this.getClass().getName(),
						"Exception message '" + ex.getMessage(), Status.FAIL);
				ex.printStackTrace();
			}
		}
	}
	
	/*
	 **************************************************************************************
	 * Method Name             : ReduceScreenshotSize
	 * Description             : this method will access the mainframe screenshots folder and invoke the resizeImage method to reduce the screenshots size
	 * Input parameter   	   : None
	 * Author                  : TTS Automation
	 ***************************************************************************************
	 */
	public void ReduceScreenshotSize(String folderpath) throws IOException{
		
		//get the list of files count and send the originalImage and type details to resizeImage method
		File[] files = new File(folderpath).listFiles();
		for (File file : files) {
		    if (file.isFile()) {
	    	  	String filepath = folderpath + "\\" + file.getName();
	    	  	if (filepath.contains(".png")) {
		    	  	BufferedImage originalImage = ImageIO.read(new File(filepath));
			  		int type = originalImage.getType() == 0? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
			  		BufferedImage resizeImagePng = resizeImage(originalImage, type);
			  		ImageIO.write(resizeImagePng, "png", new File(filepath));
	    	  	}
		    }
	    }
	}
	
	/*
	 **************************************************************************************
	 * Method Name             : BufferedImage resizeImage
	 * Description             : this method will reduce the mainframe screenshots size from MBs to KBs
	 * Input parameter   	   : originalImage, type of image
	 * Author                  : TTS Automation
	 ***************************************************************************************
	 */
	private static BufferedImage resizeImage(BufferedImage originalImage, int type){
		
    	int IMG_WIDTH = 1364;
    	int IMG_HEIGHT = 768;
		BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
		g.dispose();
	
		return resizedImage;
    }
	
	/*
	 **************************************************************************************
	 * Method Name             : RandomNumberGenerator
	 * Description             : this method will generate random number between 100-999
	 * Input parameter   	   :- 
	 *  Author                  : TTS Automation
	 ***************************************************************************************
	 */
	public static  int RandomNumberGenerator() {

		Random randomObj = new Random();
		int numb = randomObj.ints(100, 999).findFirst().getAsInt(); 
		System.out.println(numb);
		return numb;


	}
	/*
	 **************************************************************************************
	 * Method Name             : SwitchWindow
	 * Description             : this method will switch the window based on the window Title
	 * Input parameter   	   :- 
	 *  Author                  : TTS Automation
	 ***************************************************************************************
	 */
	public  void SwitchWindow(String WindowTitle) {

		try {
			WebDriverWait wait = new WebDriverWait(driver, 20);
			System.out.println("Size of Windows : "+driver.getWindowHandles().size());
			for(String handle:driver.getWindowHandles())

			{
				String myTitle = driver.switchTo().window(handle).getTitle();
				if(myTitle.equalsIgnoreCase(WindowTitle))
				{
					driver.switchTo().window(handle);
					//wait.until(ExpectedConditions.v
					System.out.println("Title after switching "+driver.getTitle());
					break;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed to switch Window due to : "+e.getMessage());
		}


	}
}



