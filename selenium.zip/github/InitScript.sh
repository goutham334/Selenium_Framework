#!/bin/bash

java -cp ".;./SupportHelperUtils/External_Jars/*" TestSuiteRunner.TestSuiteRunner