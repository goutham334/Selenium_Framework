package BusinessKeywordLib;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import com.framework.Utility.Status;

import PageFactory.JobListPO;
import SupportHelperUtils.DriverScript;
import SupportHelperUtils.KeywordHelper;
import SupportHelperUtils.ReusableLibrary;
import SupportHelperUtils.ScriptHelper;

public class JobList extends ReusableLibrary {

	KeywordHelper keywordHelper = new KeywordHelper(scriptHelper);
	ArrayList<String> reports= new ArrayList<String>();
	public static String fileName;
	public static File downloadDirectory;

	ArrayList<String> actFileNames = new ArrayList<String>();
	public static String rootPath=DriverScript.reportLocation+"\\PDF";
	public static SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
	public static Date d=new Date();
	public static String FinalReport="final_"+sdf.format(d);
	int status = 0;

	public JobList(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}

	public void clickAttachmentsLink()
	{
		System.out.println("attachments link");
		PageFactory.initElements(driver,JobListPO.class);
		try {
			int count=0;
			boolean flag=true;
			System.out.println("before while");
			while(JobListPO.attachmentLink.size()==0 && flag==true)
			{
				//new WebDriverWait(driver,5).until(ExpectedConditions.visibilityOf(JobListPO.attachmentLink.get(0)));
				driver.executeScript("arguments[0].click()",JobListPO.search);
				keywordHelper.safeWaitForStaleElement(JobListPO.search, 30);
				new WebDriverWait(driver,30).until(ExpectedConditions.elementToBeClickable(JobListPO.search));
				count++;

				System.out.println("Cliked on the search button "+count+" times");
				if(count==3)
				{
					flag=false;
				}

				new WebDriverWait(driver,5).until(ExpectedConditions.visibilityOf(JobListPO.attachmentLink.get(0)));
			}
			System.out.println("after while");

			System.out.println(JobListPO.attachmentLink.size());

			if(JobListPO.attachmentLink.size() > 0)
			{
				new WebDriverWait(driver,30).until(ExpectedConditions.elementToBeClickable(JobListPO.attachmentLink.get(0)));
				System.out.println("file name: "+JobListPO.attachmentLink.get(0).getText());
				try {
					driver.executeScript("arguments[0].click()",JobListPO.attachmentLink.get(0));
				}
				catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("error is: "+e.getMessage());
				}
				report.updateTestLog("Click on Attachment Link", "Successfully clicked on the Attachment Link", Status.PASS);
			}
			else
			{
				report.updateTestLog("Click on Attachment Link", "Attachment Link not available", Status.FAIL);	
			}
		} catch (Exception | Error e) {

			e.printStackTrace();
			System.out.println(e.getMessage());
			report.updateTestLog("Click on Attachment Link", "Failed to click on the Attachment Link", Status.FAIL);
		}
	}		


	public void downloadPDFfile()
	{
		System.out.println("download PDF file");

		String currentTestCase=dataTable.getData("Sheet_1","TC_ID");
		String currentIteration=dataTable.getData("Sheet_1","Iteration");
		String subIteration=dataTable.getData("Sheet_1","SubIteration");

		System.out.println("Current test case name is: "+currentTestCase+"_"+currentIteration+subIteration);

		downloadDirectory=new File(rootPath+"/"+currentTestCase+"_"+currentIteration+subIteration);

		System.out.println("download directory is:"+downloadDirectory.getPath());
		if(!downloadDirectory.exists())
		{
			downloadDirectory.mkdirs();
		}

		PageFactory.initElements(driver,JobListPO.class);

		try {

			//JobListPO.jobIdColumn.click();
			try {

				/*System.out.println("waiting for autoIT script to download file to complete: "+Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\other files\\download.exe").waitFor());
				System.out.println("waiting for autoIT script to close window to complete: "+Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\other files\\closewindow.exe").waitFor());*/

				String filepath = System.getProperty("user.dir")+"\\other files\\";
				System.out.println("FILE PATH - " + filepath);
				Screen s = new Screen();
				Pattern btn_SaveFile = new Pattern(filepath +"btn_SaveFile.PNG");
				Pattern closePopUp = new Pattern(filepath +"Close.PNG");
				s.click(btn_SaveFile);
				Thread.sleep(10000);
				s.click(closePopUp);





			}
			catch(Exception | Error exp)
			{
				exp.printStackTrace();
				System.out.println("THE ERROR MESSAGE IS: "+exp.getMessage());
			}


			fileName=System.getProperty("user.dir")+"\\downloaded files\\"+JobListPO.attachmentLink.get(0).getText();

			File file= new File(fileName);
			if(file.exists())
			{
				report.updateTestLog("Download file", "File "+JobListPO.attachmentLink.get(0).getText()+" has been downloaded", Status.PASS);

				FileUtils.moveToDirectory(file, downloadDirectory,false);
			}
			else
			{ 
				report.updateTestLog("Download file", "File "+JobListPO.attachmentLink.get(0).getText()+" has not been downloaded", Status.FAIL);
			}
		}
		catch(Exception | Error e)
		{
			e.printStackTrace();
			report.updateTestLog("Download file", "Error while downloading the file", Status.FAIL);
		}
	}



	public void comparePDFData() throws Exception
	{	
		ArrayList<String> fileList=new ArrayList<String>();

		File pdfValidationReports=new File(rootPath);
		if(!pdfValidationReports.exists())
		{
			pdfValidationReports.mkdirs();
		}

		File log=new File(downloadDirectory.getPath()+"\\Log");
		System.out.println("screenshot:"+log.getPath());

		if(!log.exists())
		{
			log.mkdirs();
		}

		File temp=new File(downloadDirectory.getPath()+"\\temp");
		System.out.println("temp:"+temp.getPath());
		if(!temp.exists())
		{
			temp.mkdirs();
		}

		File finalFolder=new File(downloadDirectory.getPath()+"\\Final");
		System.out.println("finalFolder:"+finalFolder.getPath());
		if(!finalFolder.exists())
		{
			finalFolder.mkdirs();
		}

		File finalFolder1=new File(downloadDirectory.getPath()+"\\Final\\"+FinalReport);
		System.out.println("screenshot:"+finalFolder1.getPath());
		if(!finalFolder1.exists())
		{
			finalFolder1.mkdirs();
		}


		try {


			File[] dir=downloadDirectory.listFiles();
			for(File f:dir)
			{
				if(f.isFile())
				{
					fileList.add(f.getPath());
				}
			}

			if(PDFValidation.Compare(fileList.get(0),fileList.get(1)))
			{
				report.updateTestLog("Validate the ASC840 and the ASC842 reports", "The ASC840 and the ASC842 reports are same", Status.PASS);

			}
			else if(!PDFValidation.Compare(fileList.get(0),fileList.get(1)) && PDFValidation.pageCountMismatch==true)
			{
				report.updateTestLog("Validate the ASC840 and the ASC842 reports", "The ASC840 and the ASC842 reports do not have the same number of pages", Status.FAIL);
			}
			else
			{
				report.updateTestLog("Validate the ASC840 and the ASC842 reports", "The ASC840 and the ASC842 reports are not the same", Status.FAIL);

			}

		}

		catch(Exception | Error e)
		{
			e.printStackTrace();
			report.updateTestLog("Validate the ASC840 and the ASC842 reports", "Error while validating the ASC840 and the ASC842 reports", Status.FAIL);


		}

	}




}
