package BusinessKeywordLib;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.documentinterchange.taggedpdf.PDTableAttributeObject;
import org.apache.pdfbox.printing.PDFPrintable;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/**
 * This is an example on how to extract text line by line from pdf document
 */
public class GetLinesFromPDF extends PDFTextStripper {

	static List<String> lines = new ArrayList<String>();

	public GetLinesFromPDF() throws IOException {
	}

	/**
	 * @throws IOException If there is an error parsing the document.
	 * @throws InvalidFormatException 
	 */
	public static void main( String[] args ) throws IOException, InvalidFormatException    {
		PDDocument document=null, document1 = null;
		HSSFWorkbook workbook;
		int count=0;
		//LeaseFinanceIncomeScheduleReport.rpt-July-31-2018-6Hr-48Min.pdf
		String fileName = "C:\\Users\\d26479\\Downloads\\LeaseFinanceIncomeScheduleReport.rpt-July-31-2018-10Hr-13Min.pdf";
		String fileName1 = "C:\\Users\\d26479\\Downloads\\LeaseFinanceIncomeScheduleReport.rpt-July-31-2018-6Hr-48Min.pdf";
		String excelFile="C:\\Users\\d26479\\Downloads\\LeaseFinanceIncomeScheduleReport-July-31-2018-6Hr-48Min.xls";
		//String fields="Account #,Customer Name,Lease Sequence #,Lease Schedule,Equipment Cost,Net Investment,FMV,Mark Up,LeaseAssets IDC,LeaseAssets IDC Treatment,FinanceAssets IDC,Currency,Accounting Standard,Lease Term,Days In year,Lease Structure,Advance/Arrears,Lease Payment,Upfont ,Interim,Residual Booked,Residual Expected";

		try {
			document = PDDocument.load( new File(fileName));
			PDFTextStripper stripper = new PDFTextStripper();
			stripper.setSortByPosition( true );
			stripper.setStartPage( 0 );
			stripper.setEndPage( document.getNumberOfPages());
			//PDTableAttributeObject object= new PDTableAttributeObject();
			//System.out.println(object.getColSpan());
			String text1=stripper.getText(document);
			String[] val1=text1.split("\n");
			for(String s:val1)
			{
				System.out.println(s);
			}
			
			File file= new File(excelFile);
			if(!file.exists()) {
				file.createNewFile();
				//workbook=WorkbookFactory.create(file);
			}

		
	
				workbook = new HSSFWorkbook();
				HSSFSheet sheet = workbook.createSheet("LeaseFinance");
				//sheet.getActiveCell();
				Row row=sheet.createRow(1);
				row=sheet.getRow(1);
				Cell cell= row.createCell(1);
				cell.setCellValue(text1);
				 FileOutputStream fileOut = new FileOutputStream(file);
		            workbook.write(fileOut);
		            fileOut.close();
		            workbook.close();
			 
			//workbook = new HSSFWorkbook();
			
			
		/*	document1 = PDDocument.load( new File(fileName1));
			PDFTextStripper stripper1 = new PDFTextStripper();
			stripper1.setSortByPosition( true );
			stripper1.setStartPage( 0 );
			stripper1.setEndPage( document1.getNumberOfPages());
			String text2=stripper.getText(document1);*/
			
/*			System.out.println(text1.replaceAll("\n","").toLowerCase().replaceAll(" ","").trim());
			System.out.println("**************************");
			System.out.println("**************************");
			System.out.println("**************************");
			System.out.println(text2.replaceAll("\n","").toLowerCase().replaceAll(" ","").trim());*/
			
			/*String[] val1=text1.split("\n");
			String[] val2=text2.split("\n");
			
			System.out.println(val1.length);
			System.out.println(val2.length);
			
			for(int i=0;i<val1.length;i++)
			{
				System.out.println(val1[i].toLowerCase().replaceAll(" ",""));
				System.out.println(val2[i].toLowerCase().replaceAll(" ",""));
				System.out.println("\n");
				System.out.println("\n");
				
				if(val1[i].toLowerCase().replaceAll(" ","").equals(val2[i].toLowerCase().replaceAll(" ","")))
				{
					count++;
				}
			}
			
			if(count==val1.length)
			{
				System.out.println("true");
			}
			else
			{
				System.out.println("true");
			}*/
			
			
			/*if(text1.equalsIgnoreCase(text2))
			{
				System.out.println("true");
			}
			else
			{
				System.out.println("false");
			}
			*/
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			/*String[] val= text1.split("\n");
			
			for(int i=0;i<val.length;i++)
			{
				System.out.println(val[i]);
			}*/
			
			
			/*String[] validateFields= fields.split(",");
			for(int i=0;i<validateFields.length;i++)
			{
				for(int j=0;j<val.length;j++)
				{
					if(val[j].toLowerCase().contains(validateFields[i].toLowerCase()))
							{
								count++;
							}
				}
			}
			
			System.out.println(count);
			System.out.println(validateFields.length);
			if(count==validateFields.length)
			{
				System.out.println("true");
			}
			else
			{
				System.out.println("false");
			}
*/







			//System.out.println(text1);                


			


		}
		finally {
			if( document!= null ) {
				document.close();

			}
		}
	}


}