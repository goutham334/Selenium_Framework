#!/bin/bash

java -cp ".;./SupportHelperUtils/External_Jars/*" org.testng.TestNG testng_regression.xml