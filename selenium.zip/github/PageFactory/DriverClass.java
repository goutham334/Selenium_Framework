package PageFactory;

import org.openqa.selenium.WebDriver;
import PageFactory.DriverClass;

public abstract class DriverClass {
	public static WebDriver driver;
	public static boolean bResult;

	public DriverClass(WebDriver driver){
		DriverClass.driver = driver;
		DriverClass.bResult = true;
	}
}
