package PageFactory;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class JobListPO {
	
	@FindBy(how=How.ID, using="igtxtctl00_FC_PH_schSearchControl_bshBasicSearch_OneInt32ctl00_FC_PH_schSearchControlrRrrRrrRr1rRr0")
	public static WebElement jobId;
	
	@FindBy(how=How.ID, using="ctl00_FC_PH_schSearchControl_cmdSearch_cmdButtonControl")
	public static WebElement search;
	
	@FindBy(how=How.CSS, using="#ctl00xFCxPHxgrdListxgrdList_rc_0_7 > nobr > a")
	public static List<WebElement> attachmentLink;
	
	@FindBy(how=How.CSS, using="#ctl00xFCxPHxgrdListxgrdList_rc_0_0 > nobr")
	public static WebElement jobIdColumn;

}
